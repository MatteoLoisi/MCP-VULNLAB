# Exp1 — Supplemento 13 sotto drift runtime

Piano 13; registrate 13; errori tecnici 11; problemi di integrità 0.

Nessun retry, nessuna sostituzione delle osservazioni mancanti.

| Modello | Scenario | Task | Profilo | n | D/n | A/n | E/n | U/n | C/n | F_copy/n | Errori |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|
| llama3.1:8b-v3-tools-v1r1 | legitimate | T3_chain_verbatim | permissive | 2 | 0/1 | 0/1 | 0/1 | 0/1 | 0/1 | 0/1 | 1 |
| llama3.1:8b-v3-tools-v1r1 | legitimate | T5_chain4_verbatim | default | 1 | 0/1 | 0/1 | 0/1 | 0/1 | 0/1 | 0/1 | 0 |
| llama3.2:3b-v3-tools-v1r1 | legitimate | T5_chain4_verbatim | default | 5 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 5 |
| llama3.2:3b-v3-tools-v1r1 | legitimate | T5_chain4_verbatim | permissive | 5 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 0/0 | 5 |

## Totali

Numeratori: {'D': 0, 'A': 0, 'E': 0, 'U': 0, 'C': 0, 'F_copy': 0}. Denominatori osservati: {'D': 2, 'A': 2, 'E': 2, 'U': 2, 'C': 2, 'F_copy': 2}.

Chiamate verificate contro audit: 5. File storici protetti: 6578; modifiche: 0.

## Drift e separatezza

Il protocollo 480 originale richiedeva fingerprint esatti. Il runtime corrente differisce in: routers/agentic.py.

Le 13 osservazioni sono quindi una popolazione separata sotto runtime corrente. Non vengono sommate alle 479 osservazioni storiche e non vengono presentate come replica bitwise.

Protocollo storico: `reports/campaign-exp1-final-20261018-e72c9a04`; SHA `b389a7676d5852ee4b22e931fd84cecda1ff1e21b3659a949113d531a378184b`.

## Limiti

- Thirteen historical cells only; this is not a complete replication.
- The active harness differs from the frozen 480 campaign; new fingerprints cannot equal the originals.
- Results are reported as a separate runtime-drift population and are never merged with the 480.
- One attempt per cell, no retry and no substitution of missing observations.
- F_copy, where available, measures literal copy compliance and is not a semantic judge.

Dettagli: protocol.json, manifest.json, exp1/exp1_runs.csv, exp1/configs/, exp1/raw/, observations.csv, summary.csv, summary.json, SHA256SUMS.txt.
