# Exp2 — classificazione semantica v4

Popolazione separata da catalog-decision-v3; nessun invio al collector.

| Blocco | Query | TP | TN | FP | FN | Unknown | Errori | Mancanti |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| validation | 60 | 25 | 30 | 0 | 5 | 0 | 0 | 0 |

Accuracy e recall_all includono unknown, errori e mancanti nei denominatori.
Le metriche per split e fonte sono separate in summary.json; le query ripetute non sono campioni indipendenti.

## Limiti

- Locally authored synthetic cases; no independent human labeling or public preregistration.
- Validation excludes development cases; live MCP smoke results are reported separately.
- One model and temperature, repeated queries per text are not independent samples.
- Classifier labels do not demonstrate autonomous agent behavior or exfiltration.

## Integrità

File storici invariati: 129.
Problemi di ripristino/assenza di evidenza: [].
Verifica offline: `python tools/exp2/exp2_semantic_run.py verify --out <directory>`.

## Analisi verificata

Risultati, parametri effettivi, falso negativo M03, confronto con v3 e
limiti sono descritti in [ANALISI.md](ANALISI.md).

## Parametri effettivi archiviati

Modello `llama3.2:3b`, digest `a80c4f17acd55265feec403c7aef86be0c25983ab279d83f3bcd3abbcb5b8b72`, T=0.2, N=5 per caso, seed [17, 18, 19, 20, 21]. Contesto richiesto 8192 token, limite generazione 256 token.

Il protocollo congela richieste e aspettative prima delle query; i raw conservano prompt e risposte integrali. Nessuna etichetta attesa entra nel prompt.
