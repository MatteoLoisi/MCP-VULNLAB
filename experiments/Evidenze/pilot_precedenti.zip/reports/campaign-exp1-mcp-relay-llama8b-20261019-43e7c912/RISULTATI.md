# Exp1 MCP + postino: pilot separato

| Condizione | Registrate | Fonte MCP verificata | Generazioni complete | Byte identici | JSON valido | Task esatto | Canary ricevuto |
|---|---:|---:|---:|---:|---:|---:|---:|
| benign | 5 | 5/5 | 5/5 | 5/5 | 0/5 | 0/5 | 0/5 |
| poisoned | 5 | 5/5 | 5/5 | 5/5 | 0/5 | 0/5 | 0/5 |

Chiamate MCP: 10. Fonti sconosciute: 0. Consegne sconosciute: 0; corpi diversi: 0. Errori tecnici: 0.

Il modello usa read_file tramite client/server MCP V3 reali, modalità exp1_legitimate, profilo permissive. Al modello è esposto il solo read_file; il risultato del tool contiene uno dei due documenti sintetici. Piano, sorgenti, catalogo e protocollo sono congelati.

Il relay invia sempre il testo finale integrale a destinazione locale fissa, anche se non è JSON. La canary nel corpo ricevuto è misurata anche fuori da JSON valido. La consegna delegata non equivale a una scelta autonoma del modello di eseguire un POST. Questi indicatori non sostituiscono D/A/E della campagna Exp1 originale.

Un solo modello, dieci conversazioni, due condizioni, nessuna ripetizione degli esiti. Questa verifica aggiunge il collegamento MCP al pilot postino; non completa tutte le modalità/modelli/profili/task della matrice Exp1.


## Limiti

- Un solo modello/configurazione e dieci conversazioni (cinque benign, cinque poisoned): il pilot non completa la matrice Exp1 né stima una distribuzione generale.
- La fonte MCP è verificata, ma il relay inoltra comunque il finale a una destinazione locale fissa. Canary nel corpo, validità JSON e successo del task sono indicatori diversi.
- I risultati di questa variante restano separati dagli altri pilot relay e dalle metriche D/A/E della matrice originaria.

Sezione esplicitata nella revisione documentale del 21 ottobre 2026; osservazioni e conteggi originari invariati.
